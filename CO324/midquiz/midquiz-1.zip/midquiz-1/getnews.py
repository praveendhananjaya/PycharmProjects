#!/usr/bin/env python3
import sys
import requests
from bs4 import BeautifulSoup

SITE='https://lite.cnn.io/'

def get_links(html, keywords):
    #TODO
    pass

if __name__ == "__main__":  
    if not len(sys.argv)  > 1:
        print (f'usage: getnews.py keyword')
        exit(-1)

    result = requests.get(SITE)
    keywords = sys.argv[1:]
    get_links(result.text, keywords)