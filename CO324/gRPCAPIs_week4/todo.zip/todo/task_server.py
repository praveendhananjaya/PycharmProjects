import logging
from concurrent.futures import ThreadPoolExecutor
from grpc import server
import task_pb2, task_pb2_grpc


class TaskapiImpl(task_pb2_grpc.TaskapiServicer):
    """Dummy implementation of the Taskapi service"""

    def __init__(self):
        # initialise a Tasks attribute to store our tasks.
        self.tasks = task_pb2.Tasks()

    def addTask(self, request, context):
        # TODO: implement this!

    def delTask(self, request, context):
        # TODO: implement this!

    def listTasks(self, request, context):
        # TODO: implement this!


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    taskserver = server(ThreadPoolExecutor(max_workers=10))
    task_pb2_grpc.add_TaskapiServicer_to_server(TaskapiImpl(), taskserver)
    taskserver.add_insecure_port("[::]:50051")
    taskserver.start()
    taskserver.wait_for_termination()
